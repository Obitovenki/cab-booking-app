package com.example.cabbooking

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.homepage.CabBookingRequestFragment.Companion.arrayList
import com.example.homepage.DivisionAdapter
import com.example.homepage.PickUpPointAdapter
import com.example.homepage.ReportingToAdapter
import com.example.homepage.databinding.FragmentBottomSheetBinding
import com.example.homepage.model.Division
import com.example.homepage.model.PickupPoint
import com.example.homepage.model.ReportingTo
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlin.properties.Delegates


class BottomSheetFragment(var bottomSheetResultListener: BottomSheetResult) :
    BottomSheetDialogFragment(),
    DivisionAdapter.OnItemClickListener,
    ReportingToAdapter.OnItemClickListener,
    PickUpPointAdapter.OnItemClickListener {

    var value by Delegates.notNull<Int>()


    private var _binding: FragmentBottomSheetBinding? = null

    private val binding get() = _binding!!
    val arraylist = arrayList
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentBottomSheetBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val division:List<Division> = arraylist.flatMap { it.divisions }
        val reportingto:List<ReportingTo> = arraylist.flatMap { it.reportingTo }
        val pickuppoint:List<PickupPoint> = arraylist.flatMap { it.pickupPoints }

        val adapter = when(value) {
            1 -> (DivisionAdapter(division,this))
            2 -> (ReportingToAdapter(reportingto,this))
            else -> (PickUpPointAdapter(pickuppoint,this))}

        binding.rcview0.layoutManager = LinearLayoutManager(requireContext())
        binding.rcview0.adapter = adapter
    }

    interface BottomSheetResult {
        fun itemPass(dataClass1: Division)
        fun itemPass(dataClass2: ReportingTo)
        fun itemPass(dataClass3: PickupPoint)
    }

    override fun onItemSelected(dataClass2: ReportingTo) {
        Log.d("TAG", "onItemSelected: "+ dataClass2)
        bottomSheetResultListener.itemPass(dataClass2)

    }

    override fun onItemSelected(dataClass3: PickupPoint) {
        Log.d("TAG", "onItemSelected: "+ dataClass3)
        bottomSheetResultListener.itemPass(dataClass3)

    }

    override fun onItemSelected(dataClass1: Division) {
        Log.d("TAG", "onItemSelected: "+ dataClass1)
        bottomSheetResultListener.itemPass(dataClass1)
    }


}