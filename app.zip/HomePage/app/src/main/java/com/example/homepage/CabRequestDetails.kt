package com.example.cabbooking

data class CabRequestDetails(
    val CompletionTime: String,
    val DivisionID: Int,
    val DropPoint: String,
    val EmpID: Int,
    val EmployeeName: String,
    val FromDate: String,
    val ManagerID: Int,
    val PickUpPointID: Int,
    val Status: String,
    val ToDate: String
)