package com.example.homepage

import com.example.homepage.model.DropDownDataResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

//"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbXBfaWQiOjEwMDAwMDEsImlhdCI6MTcxODM2MjAxNX0.CbotVLBBBbLgVhRzYhudPyXRXqwI_F952Q_PSi7Z1_o"


interface bottomSheetApiService {

    @POST("cabBooking/showRequestMasterDetails")
    fun getDropDownData(
        @Header("Authorization") token: String,
        @Body masterRequest: MasterRequest
    ): Call<DropDownDataResponse>

}

