package com.example.homepage

data class RecyclerViewDataItem(
    val ApprovedOn: Any,
    val Comment: Any,
    val CompletionTime: String,
    val DivisionID: Int,
    val DivisionName: String,
    val DropPoint: String,
    val FromDate: String,
    val ID: Int,
    val ManagerID: Int,
    val ManagerName: String,
    val PickUpName: String,
    val PickUpPointID: Int,
    val Status: String,
    val TimeSlot: Any,
    val ToDate: String
)