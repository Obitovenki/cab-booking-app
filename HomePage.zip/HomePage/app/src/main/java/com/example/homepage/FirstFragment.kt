package com.example.homepage

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.airbnb.lottie.LottieAnimationView
import com.example.homepage.Login.Companion.empIdKey
import com.example.homepage.Login.Companion.tokenKey
import com.example.homepage.databinding.FragmentFirstBinding
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FirstFragment : Fragment() {
    private lateinit var sharedPreferences: SharedPreferences
    private var _binding: FragmentFirstBinding? = null
    private val binding get() = _binding!!
    lateinit var apiService: RecyclerViewApiService
    private lateinit var adapter: AdapterClass
    private lateinit var swiperefresh: SwipeRefreshLayout


    private lateinit var animationView: LottieAnimationView
    private val animationDuration = 600L


    private val animationHandler = Handler()
    private val animationRunnable = Runnable {
        animationView.visibility = View.INVISIBLE

        // Once animation is hidden, show other UI elements if needed
        binding.recyclerView.visibility = View.VISIBLE
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        animationView = binding.animation
        adapter = AdapterClass(emptyList())
        apiService=RetrofitClient.apiServicerecycler
        swiperefresh = binding.swipe



        sharedPreferences = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)


        binding.bookCab.setOnClickListener {
            if (!isNetworkAvailable()) {
                Toast.makeText(requireContext(), "No internet connection", Toast.LENGTH_SHORT)
                    .show()
            } else {

                findNavController().navigate(R.id.action_firstFragment_to_secondFragment)
            }
        }

        binding.logoutBtn.setOnClickListener{
            val editor = sharedPreferences.edit()
            editor.putBoolean("isLoggedIn", false)
            editor.apply()
            findNavController().navigate(R.id.action_firstFragment_to_login3)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter



        fetchCabBookingData()




        // SWIPEREFRESH FUNCTION
        binding.swipe.setOnRefreshListener {

            fetchCabBookingData()


        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    private fun showAnimation() {
        animationView.visibility = View.VISIBLE
        animationView.playAnimation()
        animationHandler.postDelayed(animationRunnable, animationDuration)
    }

// To fetch cab booking data from the api
    private fun fetchCabBookingData(){
        if (!isNetworkAvailable()) {
            if(swiperefresh.isRefreshing)
            {
                swiperefresh.isRefreshing=false
            }
            Toast.makeText(requireContext(), "No internet connection", Toast.LENGTH_SHORT).show()
            return
        }
        val token = sharedPreferences.getString(tokenKey,"")?:""
        val empID = sharedPreferences.getInt(empIdKey,0)

        val listRequest = ListRequest(empID)
        apiService.fetchCabBookingData(token, listRequest).enqueue(object : Callback<RecyclerViewData>
        {
            override fun onResponse(call: Call<RecyclerViewData>, response: Response<RecyclerViewData>) {

                if(swiperefresh.isRefreshing)
                {
                    swiperefresh.isRefreshing=false
                }

                if (response.isSuccessful) {
                    showAnimation()
                    val data = response.body()
                    data?.let {
                        adapter.updateData(it)
                    }
                }
                else{
                    val errorBody = response.errorBody().toString()
                    val gson = Gson()
                    val errorResponse =
                        gson.fromJson<ErrorMessage>(errorBody, ErrorMessage::class.java)
                    if (errorResponse.message != null) {

                        Toast.makeText(
                            requireContext(),
                            "" + errorResponse.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    } else if (errorResponse.error != null) {
                        Toast.makeText(
                            requireContext(),
                            "" + errorResponse.error,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

            override fun onFailure(call: Call<RecyclerViewData>, t: Throwable) {
                Log.d("TAG","On failure"+ t.localizedMessage)
                if (swiperefresh.isRefreshing) {
                    swiperefresh.isRefreshing = false
                }

            }

        })

    }
    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }
}
