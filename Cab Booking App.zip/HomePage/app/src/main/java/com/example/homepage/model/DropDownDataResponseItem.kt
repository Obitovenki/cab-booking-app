package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class DropDownDataResponseItem(
    @SerializedName("employeeDetails") val employeeDetails: EmployeeDetails
)
