package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class PickupDetails(
    @SerializedName("PickUpName") val name: String,
    @SerializedName("PickUpPointID") val id: Int
)