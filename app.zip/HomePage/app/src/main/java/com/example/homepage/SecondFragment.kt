package com.example.homepage

import android.app.DatePickerDialog
import android.content.Context
import android.content.SharedPreferences
import android.icu.text.SimpleDateFormat
import android.net.ConnectivityManager
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.text.format.DateFormat.is24HourFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.cabbooking.BottomSheetFragment
import com.example.cabbooking.CabBookingResponse
import com.example.cabbooking.CabBookingResponseItem
import com.example.cabbooking.CabRequestDetails
import com.example.homepage.Login.Companion.empIdKey
import com.example.homepage.Login.Companion.tokenKey
import com.example.homepage.model.Division
import com.example.homepage.model.DropDownDataResponse
import com.example.homepage.model.DropDownDataResponseItem
import com.example.homepage.model.EmployeeDetails
import com.example.homepage.model.PickupPoint
import com.example.homepage.model.ReportingTo
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.google.gson.Gson
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.hbb20.CountryCodePicker
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Calendar
import java.util.Locale


class SecondFragment : Fragment(), BottomSheetFragment.BottomSheetResult {


    lateinit var apiService: bottomSheetApiService
    lateinit var cabRequestApiService: CabRequestApiService
    private lateinit var sharedPreferences: SharedPreferences

    var selectedDivisionID: Int = 0
    var selectedManagerID: Int = 0
    var selectedPickupPointID: Int = 0
    var selectedFromDate: String = ""
    var selectedToDate: String = ""
    var selectedCompletionTime: String = ""
    lateinit var selectedDropPoint: String
    val selectedStatusPending = "Pending"
    var selectedEmpId: Int = 0
    var selectedEmpName: String = ""


    lateinit var dateInput: TextInputEditText
    lateinit var timeInput: TextInputEditText


    lateinit var text1: TextInputEditText
    lateinit var text2: TextInputEditText
    lateinit var text3: TextInputEditText
    lateinit var text4: TextInputEditText
    lateinit var phoneNumberEditText: TextInputEditText
    lateinit var phoneNumberUtil: PhoneNumberUtil
    private lateinit var ccp : CountryCodePicker
    lateinit var bookCabButton: TextView
    var demoNumberLength: Int = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        text1 = view.findViewById<TextInputEditText>(R.id.TextInputEditText1)
        text2 = view.findViewById<TextInputEditText>(R.id.TextInputEditText2)
        text3 = view.findViewById<TextInputEditText>(R.id.TextInputEditText3)
        text4 = view.findViewById<TextInputEditText>(R.id.TextInputEditText4)
        phoneNumberEditText = view.findViewById(R.id.ph_edittext1)
        ccp = view.findViewById(R.id.ccode)
        bookCabButton = view.findViewById<TextView>(R.id.book_cab_btn)


        //api

        apiService = RetrofitClient.apiServicebottom
        sharedPreferences = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        getDropDownData()

        cabRequestApiService = RetrofitClient.cabRequestApiService

        bookCabButton.setOnClickListener {
            selectedDropPoint = text4.text.toString()

            if (!isNetworkAvailable()) {
                Toast.makeText(requireContext(), "No internet connection", Toast.LENGTH_SHORT)
                    .show()
            } else {


                if (validateSubmittedData(
                        selectedCompletionTime,
                        selectedDivisionID,
                        selectedDropPoint,
                        selectedEmpId,
                        selectedEmpName,
                        selectedFromDate,
                        selectedManagerID,
                        selectedPickupPointID,
                        selectedStatusPending,
                        selectedToDate
                    )
                ) {

                    val phLength = phoneNumberEditText.text?.length
                    if (phLength == demoNumberLength) {

                        sendCabRequest()

                    } else {
                        Toast.makeText(requireContext(), "Enter valid phone number", Toast.LENGTH_SHORT).show()
                    }


                } else {
                    Toast.makeText(
                        requireContext(),
                        "Please enter all details",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }


            }
        }

        phoneNumberUtil = PhoneNumberUtil.getInstance()

        updatePhoneNumberEditTextLength()

        ccp.setOnCountryChangeListener {
            updatePhoneNumberEditTextLength()
        }

        //Date Picker
        dateInput = view.findViewById<TextInputEditText>(R.id.date_edittext1)


        dateInput.setOnClickListener {
            showDatePickerDialog(dateInput)
        }


        //Time Picker
        timeInput = view.findViewById<TextInputEditText>(R.id.time_edittext1)

        timeInput.setOnClickListener {
            openTimePicker()
        }


//1

        text1.setOnClickListener {
            val bottomSheetDialogFragment = BottomSheetFragment(this)
            bottomSheetDialogFragment.value = 1
            bottomSheetDialogFragment.isCancelable = false
            bottomSheetDialogFragment.show(parentFragmentManager, bottomSheetDialogFragment.tag)

            text1.doOnTextChanged { text, _, _, _ ->

                bottomSheetDialogFragment.dismiss()
            }
        }


//2

        text2.setOnClickListener {
            val bottomSheetDialogFragment = BottomSheetFragment(this)
            bottomSheetDialogFragment.value = 2
            bottomSheetDialogFragment.isCancelable = false
            bottomSheetDialogFragment.show(parentFragmentManager, bottomSheetDialogFragment.tag)

            text2.doOnTextChanged { text, _, _, _ ->

                bottomSheetDialogFragment.dismiss()
            }
        }

//3

        text3.setOnClickListener {
            val bottomSheetDialogFragment = BottomSheetFragment(this)
            bottomSheetDialogFragment.value = 3
            bottomSheetDialogFragment.isCancelable = false
            bottomSheetDialogFragment.show(parentFragmentManager, bottomSheetDialogFragment.tag)

            text3.doOnTextChanged { text, _, _, _ ->

                bottomSheetDialogFragment.dismiss()
            }
        }


    }//end of onviewcreated


    private fun getDropDownData() {
        val token = sharedPreferences.getString(tokenKey,"")?:""
        val empId = sharedPreferences.getInt(empIdKey,0)
        val masterRequest = MasterRequest(empId)
        apiService.getDropDownData(token, masterRequest)
            .enqueue(object : Callback<DropDownDataResponse> {
                override fun onResponse(
                    call: Call<DropDownDataResponse>,
                    response: Response<DropDownDataResponse>
                ) {

                    if (response.isSuccessful) {
                        Log.d("getDropDownData: TAG", "Response successful")

                        val dropDownDataResponse = response.body()
                        if (dropDownDataResponse != null) {
                            Log.d("response", "received:" + response.body())
                            for (DropDownDataResponseItem: DropDownDataResponseItem in dropDownDataResponse) {
                                arrayList.clear()
                                arrayList.add(DropDownDataResponseItem.employeeDetails)

                                Log.d(
                                    "getDropDownData",
                                    "onResponse: " + DropDownDataResponseItem.employeeDetails
                                )

                                selectedEmpName =
                                    DropDownDataResponseItem.employeeDetails.firstName + " " + DropDownDataResponseItem.employeeDetails.lastName
                                selectedEmpId = DropDownDataResponseItem.employeeDetails.empId

                            }


                        } else {
                            val errorBody = response.errorBody().toString()
                            val gson = Gson()
                            val errorResponse =
                                gson.fromJson<ErrorMessage>(errorBody, ErrorMessage::class.java)
                            if (errorResponse.message != null) {

                                Toast.makeText(
                                    requireContext(),
                                    "" + errorResponse.message,
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else if (errorResponse.error != null) {
                                Toast.makeText(
                                    requireContext(),
                                    "" + errorResponse.error,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                        }

                    } else {
                        Log.d("getDropDownData: TAG", "Response Not successful")
                    }

                }

                override fun onFailure(call: Call<DropDownDataResponse>, t: Throwable) {
                    Log.d("getDropDownData: TAG", "On failure" + t.localizedMessage)
                }

            })

    }


    fun sendCabRequest() {

        val cabRequestDetails = CabRequestDetails(
            selectedCompletionTime, selectedDivisionID,
            selectedDropPoint, selectedEmpId,selectedEmpName, selectedFromDate, selectedManagerID,
            selectedPickupPointID, selectedStatusPending, selectedToDate
        )
        val token = sharedPreferences.getString(tokenKey,"")?:""
        cabRequestApiService.sendCabRequest(token, cabRequestDetails)
            .enqueue(object : Callback<CabBookingResponse> {
                override fun onResponse(
                    call: Call<CabBookingResponse>,
                    response: Response<CabBookingResponse>
                ) {

                    Log.d("sendCabRequest: Request", "CabRequestDetails: ${cabRequestDetails}")

                    if (response.isSuccessful) {
                        Log.d("sendCabRequest: TAG", "Response successful")

                        val cabBookingResponse = response.body()
                        if (cabBookingResponse != null) {

                            for (cabBookingResponseItem: CabBookingResponseItem in cabBookingResponse) {
                                Log.d(
                                    "sendCabRequest",
                                    "onResponse: " + cabBookingResponseItem.toString()
                                )
                                if (cabBookingResponseItem.id == 0) {
                                    Toast.makeText(
                                        requireContext(),
                                        "${cabBookingResponseItem.message}",
                                        Toast.LENGTH_SHORT
                                    ).show() }
                            }
                            findNavController().navigate(R.id.action_secondFragment_to_firstFragment)
                        } else {
                            val errorBody = response.errorBody().toString()
                            var gson = Gson()
                            val errorResponse =
                                gson.fromJson<ErrorMessage>(errorBody, ErrorMessage::class.java)
                            if (errorResponse.message != null) {
                                Toast.makeText(
                                    requireContext(),
                                    "" + errorResponse.message,
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else if (errorResponse.error != null) {
                                Toast.makeText(
                                    requireContext(),
                                    "" + errorResponse.error,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                        }

                    } else {
                        Log.d("sendCabRequest: TAG", "Response Not successful")
                        val errorBody = response.errorBody().toString()
                        var gson = Gson()
                        Log.d("sendCabRequest: error", errorBody)

                    }

                }

                override fun onFailure(call: Call<CabBookingResponse>, t: Throwable) {
                    Log.d("sendCabRequest: TAG", "On failure" + t.localizedMessage)
                }

            })
    }

    fun validateSubmittedData(
        completionTime: String,
        divisionID: Int,
        dropPoint: String,
        empID: Int,
        employeeName: String,
        fromDate: String,
        managerID: Int,
        pickUpPointID: Int,
        status: String,
        toDate: String
    ): Boolean {

        if (divisionID == null || managerID == null || pickUpPointID == null || divisionID == 0 || managerID == 0 ||
            pickUpPointID == 0 || completionTime.isEmpty() || dropPoint.isEmpty()
            || empID.toString().isEmpty() || employeeName.isEmpty() || fromDate.isEmpty()
            || status.isEmpty() || toDate.isEmpty()
        ) {
            return false
        } else {
            return true
        }
    }

//companion object

    companion object {
        val arrayList = ArrayList<EmployeeDetails>()
    }

    private fun updatePhoneNumberEditTextLength() {
        val selectedCountryCode =  phoneNumberUtil.getRegionCodeForCountryCode(ccp.selectedCountryCodeAsInt)
        val demoNumber = (phoneNumberUtil.getExampleNumber(selectedCountryCode).nationalNumber).toString()
        demoNumberLength  = demoNumber.length

        phoneNumberEditText.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(demoNumberLength))
        // Set up TextWatcher to enforce exact length validation
        phoneNumberEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
                if (s != null && s.length != demoNumberLength) {
                    phoneNumberEditText.error = "Phone number must be $demoNumberLength digits"
                } else {
                    phoneNumberEditText.error = null
                }
            }
        })
    }


//date picker fun

    private fun showDatePickerDialog(dateInput: TextInputEditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, monthOfYear, dayOfMonth ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, monthOfYear, dayOfMonth)
                val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH)
                val formattedDate = dateFormat.format(selectedDate.time)
                dateInput.setText(formattedDate)

                val selectedDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
                selectedFromDate = selectedDateFormat.format(selectedDate.time)
                selectedToDate = selectedDateFormat.format(selectedDate.time)

            },
            year,
            month,
            day
        )

        // Set minimum date to current date
        datePickerDialog.datePicker.minDate = System.currentTimeMillis() - 1000 // Disables previous dates

        // Set maximum date to current date
        val maxCalendar = Calendar.getInstance()
        maxCalendar.add(Calendar.DAY_OF_MONTH, 0) // Allow only current date
        val maxDate = maxCalendar.timeInMillis
        datePickerDialog.datePicker.maxDate = maxDate

        datePickerDialog.setTitle("SELECT DATE")
        datePickerDialog.show()

    }

    //time picker function

    private fun openTimePicker() {
        val isSystem24Hour = is24HourFormat(requireContext())
        val clockFormat = if (isSystem24Hour) TimeFormat.CLOCK_24H else TimeFormat.CLOCK_12H
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(clockFormat)
            .setHour(12)
            .setMinute(0)
            .setTitleText("SELECT TIME")
            .build()


        picker.addOnPositiveButtonClickListener {
            val hour = picker.hour
            val minute = picker.minute
            val formattedTime = if (isSystem24Hour) {
                String.format("%02d:%02d", hour, minute)
            } else {
                val amPm = if (hour < 12) "AM" else "PM"
                String.format("%02d:%02d %s", if (hour % 12 == 0) 12 else hour % 12, minute, amPm)
            }
            timeInput.setText(formattedTime)

            selectedCompletionTime = String.format("%02d:%02d", hour, minute)

        }
        picker.show(childFragmentManager, "TAG")

    }

    override fun itemPass(dataClass1: Division) {
        val selectedItem = dataClass1.divisionName
        selectedDivisionID = dataClass1.divisionID
        text1.setText(selectedItem)
    }

    override fun itemPass(dataClass2: ReportingTo) {
        val selectedItem = dataClass2.name
        selectedManagerID = dataClass2.id
        text2.setText(selectedItem)
    }

    override fun itemPass(dataClass3: PickupPoint) {
        val selectedItem = dataClass3.name
        selectedPickupPointID = dataClass3.id
        text3.setText(selectedItem)
    }
    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }

}
































