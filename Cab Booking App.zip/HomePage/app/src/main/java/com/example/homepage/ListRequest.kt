package com.example.homepage

import com.google.gson.annotations.SerializedName

data class ListRequest(
    @SerializedName("empid") val empID:Int
)
