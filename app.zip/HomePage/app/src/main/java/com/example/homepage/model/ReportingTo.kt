package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class ReportingTo(
    @SerializedName("ReportingName") val name: String,
    @SerializedName("ReportingToID") val id: Int
)