package com.example.homepage

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class AdapterClass(private var itemList: List<RecyclerViewDataItem>) :
    RecyclerView.Adapter<AdapterClass.ViewHolder>() {
//        fun updateData(newList: List<RecyclerViewDataItem>) {
//            itemList = newList
//            notifyDataSetChanged()
//        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.fragment_cab_booking_item, parent, false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = itemList[position]
        holder.bind(item)
    }
    override fun getItemCount(): Int {
        return itemList.size
//        val limit = 5
//        return minOf(itemList.size,limit)
    }
    fun updateData(newList: List<RecyclerViewDataItem>) {
        itemList = newList
        notifyDataSetChanged()
    }
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateTextView: TextView = itemView.findViewById(R.id.date)
        private val statusTextView: TextView = itemView.findViewById(R.id.status)
//        private val pickupPointTextView: TextView = itemView.findViewById(R.id.text_pickup_point)
        private val pickupLocationTextView: TextView = itemView.findViewById(R.id.pickup_location)
//        private val textPickuptimetextview: TextView = itemView.findViewById(R.id.text_pickup_time)
        private val pickuptimetextview: TextView = itemView.findViewById(R.id.pickup_time)
//        private val dropPointTextView: TextView = itemView.findViewById(R.id.text_drop_point)
        private val dropLocationTextView:TextView = itemView.findViewById(R.id.drop_point)


        fun bind(item: RecyclerViewDataItem) {
            dateTextView.text = item.FromDate.toString()
            statusTextView.text = item.Status.toString()
//            pickupPointTextView.text = item.textPickupPoint.toString()
            pickupLocationTextView.text = item.PickUpName.toString()
//            textPickuptimetextview.text = item.textPickupTime.toString()
            pickuptimetextview.text = item.CompletionTime.toString()
//            dropPointTextView.text = item.textDropPoint.toString()
            dropLocationTextView.text = item.DropPoint.toString()

            val drawable = when (item.Status) {
                "Pending" -> R.drawable.pending
                "Approved" -> R.drawable.approved
                "Rejected" -> R.drawable.rejected
                else -> R.drawable.pending
            }
            statusTextView.background = ContextCompat.getDrawable(statusTextView.context, drawable)

        }
    }
}