package com.example.homepage

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface RecyclerViewApiService {
    @POST("cabBooking/cabbookinguseractivitylist")
    fun fetchCabBookingData(
        @Header("Authorization") token: String,
        @Body listRequest: ListRequest
    ):Call<RecyclerViewData>

}
