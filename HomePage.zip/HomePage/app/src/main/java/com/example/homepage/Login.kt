package com.example.homepage
import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.homepage.databinding.FragmentLoginBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class Login : Fragment() {
    private lateinit var sharedPreferences: SharedPreferences
    private val isLoggedInKey = "isLoggedIn"
    private val passwordKey = "password"
    private val firstNameKey = "firstName"

    private lateinit var apiService: ApiService

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiService = RetrofitClient.apiService
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sharedPreferences = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean(isLoggedInKey, false)
        if (isLoggedIn) {
            // User is already logged in, navigate to home screen
            findNavController().navigate(R.id.action_login3_to_firstFragment)
        }

        binding.loginBtn.setOnClickListener{
            if (isNetworkAvailable()) {
                val emp_idText = binding.username.text.toString()
                val password = binding.pass.text.toString()

                // Input validation
                if (emp_idText.isBlank() || password.isBlank()) {
                    Toast.makeText(requireContext(), "Please enter both username and password", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val emp_id = try {
                    emp_idText.toInt()
                } catch (e: NumberFormatException) {
                    Toast.makeText(requireContext(), "Invalid username format", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                // Show loading indicator and hide login button
                showLoading()

                val loginRequest = LoginRequest(emp_id, password)

                apiService.login(loginRequest).enqueue(object : Callback<List<LoginResponse>> {
                    override fun onResponse(call: Call<List<LoginResponse>>, response: Response<List<LoginResponse>>) {
                        hideLoading() // Hide loading indicator on response

                        if (response.isSuccessful) {
                            val loginResponse = response.body()
                            if (loginResponse != null) {
                                var isValidLogin = false

                                for (login in loginResponse) {
                                    if (login.token != null ) {
                                        val token = login.token
                                        val editor = sharedPreferences.edit()
                                        editor.putString(tokenKey, token)
                                        editor.apply()
                                    } else {
                                        isValidLogin = true

                                        val empId = emp_idText.toInt()
                                        val password = login.password
                                        val firstName = login.firstName
                                        val editor = sharedPreferences.edit()
                                        editor.putBoolean(isLoggedInKey, true)
                                        editor.putInt(empIdKey, empId)
                                        editor.putString(passwordKey, password)
                                        editor.putString(firstNameKey, firstName)
                                        editor.apply()
                                    }
                                }

                                if (isValidLogin) {
                                    // Navigate to home screen after processing all login responses
                                    findNavController().navigate(R.id.action_login3_to_firstFragment)
                                } else {
                                    // Show error message for invalid username or password
                                    Toast.makeText(requireContext(), "Invalid username or password", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                // Handle empty or null response body
                                Toast.makeText(requireContext(), "Invalid username or password", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // Handle unsuccessful HTTP response
                            Toast.makeText(requireContext(), "Login failed. Please try again later.", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<List<LoginResponse>>, t: Throwable) {
                        hideLoading() // Hide loading indicator on failure
                        // Log the error message for debugging
                        Toast.makeText(requireContext(), "Login failed. Please try again later.", Toast.LENGTH_SHORT).show()
                    }
                })
            } else {
                Toast.makeText(requireContext(), "No internet connection", Toast.LENGTH_SHORT).show()
            }
        }

        // Listen for "Done" action on the password field to hide the keyboard
        binding.pass.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                // Hide keyboard
                hideKeyboard()
                // Perform login when "Done" button on keyboard is pressed
                binding.loginBtn.performClick()
                true
            } else {
                false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val networkCapabilities = connectivityManager.getNetworkCapabilities(network)
        return networkCapabilities != null &&
                (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
    }

    private fun showLoading() {
        binding.loginBtn.visibility = View.INVISIBLE
        // Show your loading indicator (e.g., ProgressBar)
         binding.progressBar.visibility = View.VISIBLE
    }

    private fun hideLoading() {
        binding.loginBtn.visibility = View.VISIBLE
        // Hide your loading indicator (e.g., ProgressBar)
         binding.progressBar.visibility = View.GONE
    }

    private fun hideKeyboard() {
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.pass.windowToken, 0)
    }

    companion object {
        const val tokenKey = "token"
        const val empIdKey = "empId"
    }
}
