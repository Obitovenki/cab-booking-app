package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class Division(
    @SerializedName("DivisionID") val divisionID: Int,
    @SerializedName("DivisionName") val divisionName: String
)
