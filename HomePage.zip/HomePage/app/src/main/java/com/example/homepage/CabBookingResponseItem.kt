package com.example.cabbooking

data class CabBookingResponseItem(
    val id: Int,
    val message: String
)