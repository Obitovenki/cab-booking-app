package com.example.homepage

import com.example.cabbooking.CabBookingResponse
import com.example.cabbooking.CabRequestDetails
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface CabRequestApiService {
    @POST("cabBooking/addCabRequest")
    fun sendCabRequest(@Header("Authorization") token: String, @Body cabRequestDetails: CabRequestDetails): Call<CabBookingResponse>
}