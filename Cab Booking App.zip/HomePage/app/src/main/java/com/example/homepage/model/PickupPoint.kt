package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class PickupPoint(
    @SerializedName("RouteID") val id: Int,
    @SerializedName("RouteName") val name: String
)