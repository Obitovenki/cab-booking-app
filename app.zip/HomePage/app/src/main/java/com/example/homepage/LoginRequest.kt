package com.example.homepage

import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("emp_id")val empId: Int,
    @SerializedName("password")val password: String
)
