package com.example.homepage

data class ErrorMessage(
    val error:String,
    val message: String,
    val status: String
)