package com.example.homepage

class RecyclerViewData : ArrayList<RecyclerViewDataItem>()