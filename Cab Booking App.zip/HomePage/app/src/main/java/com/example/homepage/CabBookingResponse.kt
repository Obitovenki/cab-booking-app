package com.example.cabbooking

class CabBookingResponse : ArrayList<CabBookingResponseItem>()