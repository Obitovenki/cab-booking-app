package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class TimeSlot(
    @SerializedName("TimeSlotID") val id: Int,
    @SerializedName("TimeSlotName") val name: String
)