package com.example.homepage.model

import com.google.gson.annotations.SerializedName

data class EmployeeDetails(
    @SerializedName("Division") val divisions: List<Division>,
    @SerializedName("DivisionDetails") val divisionDetails: DivisionDetails,
    @SerializedName("DropDetails") val dropDetails: String,
    @SerializedName("EMPID") val empId: Int,
    @SerializedName("FirstName") val firstName: String,
    @SerializedName("ID") val id: Int,
    @SerializedName("LastName") val lastName: String,
    @SerializedName("MobileNo") val mobileNo: Any,
    @SerializedName("PickupDetails") val pickupDetails: PickupDetails,
    @SerializedName("PickupPoint") val pickupPoints: List<PickupPoint>,
    @SerializedName("ReportingTo") val reportingTo: List<ReportingTo>,
    @SerializedName("TimeSlot") val timeSlot: List<TimeSlot>
)
