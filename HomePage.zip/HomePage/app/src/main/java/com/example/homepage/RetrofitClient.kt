package com.example.homepage
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private const val BASE_URL = "http://172.16.4.25:8080/"

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
    val apiServicebottom: bottomSheetApiService by lazy {
        retrofit.create(bottomSheetApiService::class.java)
    }
    val apiServicerecycler: RecyclerViewApiService by lazy{
        retrofit.create(RecyclerViewApiService::class.java)
    }

    val cabRequestApiService: CabRequestApiService by lazy{
        retrofit.create(CabRequestApiService::class.java)
    }


}


