package com.example.homepage.model

class DropDownDataResponse : ArrayList<DropDownDataResponseItem>()