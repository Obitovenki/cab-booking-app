package com.example.homepage


import com.google.gson.annotations.SerializedName

data class MasterRequest(
    @SerializedName("empid")val empId: Int
)